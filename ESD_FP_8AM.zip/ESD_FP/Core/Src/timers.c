
/*****************************************************************************
​ ​*​ ​Copyright​ ​(C)​ 2023 ​by​ Visweshwaran Baskaran and Vidhya Palaniappan
​ ​*
​ ​*​ ​Redistribution,​ ​modification​ ​or​ ​use​ ​of​ ​this​ ​software​ ​in​ ​source​ ​or​ ​binary
​ ​*​ ​forms​ ​is​ ​permitted​ ​as​ ​long​ ​as​ ​the​ ​files​ ​maintain​ ​this​ ​copyright.​ ​Users​ ​are
​ ​*​ ​permitted​ ​to​ ​modify​ ​this​ ​and​ ​use​ ​it​ ​to​ ​learn​ ​about​ ​the​ ​field​ ​of​ ​embedded
​ ​*​ ​software.​ Visweshwaran Baskaran​, Vidhya Palaniappan ​and​ ​the​ ​University​ ​of​ ​Colorado​ ​are​ ​not​ ​liable​ ​for
​ ​*​ ​any​ ​misuse​ ​of​ ​this​ ​material.
​ ​*
*****************************************************************************/
/*
 * File name: timers.h
 * Author: Visweshwaran Baskaran and Vidhya Palaniappan
 * File Description:
 * 	This file defines the APIs to configure timer 1 and timer
 *	The functions defined in this file are:
 *			void TIM2_init(void);
 *			void TIM1_init(void);
 *			void delay_us(uint32_t us);
 * 			void delay_ms(uint32_t ms);
 *			uint32_t get_tick(void);
 *
 * Created on: 01-May-2023
 *
 * Sources:
 *
*/

#include <timers.h>
#include "stm32l5xx_hal.h"

volatile uint32_t curr_Tick = 0;  // Global variable to store reset tick

/*
 * Function to configure timer 2 for DMA transfer
 *
 * Parameters: None
 *
 * Returns: None
 */
void TIM2_init(void)
{
    RCC->AHB1ENR |= RCC_APB1ENR1_TIM2EN;
    TIM2->CR1 &= ~(TIM_CR1_DIR | TIM_CR1_CMS | TIM_CR1_ARPE | TIM_CR1_UDIS | TIM_CR1_UDIS | TIM_CR1_CKD);
    TIM2->CR2 &= ~(TIM_CR2_MMS_0 | TIM_CR2_MMS_1 | TIM_CR2_MMS_2);
    TIM2->CR2 |= TIM_CR2_MMS_2;
    TIM2->PSC = 0;
    TIM2->ARR = 624;
    NVIC_EnableIRQ(TIM2_IRQn);
    TIM2->CR1 |= TIM_CR1_CEN;
}

/*
 * Function to configure timer 1 for delays
 *
 * Parameters: None
 *
 * Returns: None
 */
void TIM1_init()
{
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    // Configure Timer 1
    TIM1->CR1 &= ~TIM_CR1_CEN;     // Disable Timer 1

    TIM1->PSC = 71;                // Prescaler = 72-1
    TIM1->ARR = 0xFFFF - 1;        // Counter period = 0xFFFF - 1

    TIM1->EGR |= TIM_EGR_UG;       // Generate an update event to reload the prescaler and the repetition counter

    // Configure Timer 1 trigger event
    TIM1->SMCR &= ~TIM_SMCR_TS;    // Select internal trigger 0 (ITR0) as the trigger source
    TIM1->SMCR |= TIM_SMCR_TS_2;
    TIM1->SMCR &= ~TIM_SMCR_SMS;   // Select reset mode

    // Enable Timer 1 update interrupt
    TIM1->DIER |= TIM_DIER_UIE;

    NVIC_SetPriority(TIM1_UP_IRQn, 0);  // Set interrupt priority
    NVIC_EnableIRQ(TIM1_UP_IRQn);       // Enable Timer 1 interrupt in NVIC

    TIM1->CR1 |= TIM_CR1_CEN;      // Enable Timer 1
}

void TIM1_UP_IRQHandler(void)
{
    if (TIM1->SR & TIM_SR_UIF)  // Check if update interrupt flag is set
    {
        TIM1->SR &= ~TIM_SR_UIF;  // Clear the update interrupt flag
        curr_Tick++;
    }
}

/*
 * Function to add a delay of 'n' us
 *
 * Parameters:
 * us, no. of microseconds of delay required
 *
 * Returns: None
 */
void delay_us(uint32_t us)
{
    uint32_t startTick = curr_Tick;
    while ((curr_Tick - startTick) < us);
}

/*
 * Function to add a delay of 'n' ms
 *
 * Parameters:
 * ms, no. of milliseconds of delay required
 *
 * Returns: None
 */
void delay_ms(uint32_t ms)
{
    delay_us(ms * 1000);
}


/*
 * Function to return current tick time of timer 1
 *
 * Parameters: None
 *
 * Returns: curr_tick, current tick time
 */
uint32_t get_tick(void)
{
	return curr_Tick;
}

