/*****************************************************************************
​ ​*​ ​Copyright​ ​(C)​ 2023 ​by​ Visweshwaran Baskaran and Vidhya Palaniappan
​ ​*
​ ​*​ ​Redistribution,​ ​modification​ ​or​ ​use​ ​of​ ​this​ ​software​ ​in​ ​source​ ​or​ ​binary
​ ​*​ ​forms​ ​is​ ​permitted​ ​as​ ​long​ ​as​ ​the​ ​files​ ​maintain​ ​this​ ​copyright.​ ​Users​ ​are
​ ​*​ ​permitted​ ​to​ ​modify​ ​this​ ​and​ ​use​ ​it​ ​to​ ​learn​ ​about​ ​the​ ​field​ ​of​ ​embedded
​ ​*​ ​software.​ Visweshwaran Baskaran​, Vidhya Palaniappan ​and​ ​the​ ​University​ ​of​ ​Colorado​ ​are​ ​not​ ​liable​ ​for
​ ​*​ ​any​ ​misuse​ ​of​ ​this​ ​material.
​ ​*
*****************************************************************************/
/*
 * File name: FSM.c
 * Author: Visweshwaran Baskaran and Vidhya Palaniappan
 * File Description:
 * 	This file defines the API required for the state machine that drives the application
 *
 * Created on: 01-May-2023
*/

#include "FSM.h"
#include "bitmap.h"
#include "LUT.h"
#define BUFFER_SIZE_128 128
#define BUFFER_SIZE_2 2
extern int done_flag, flag, count, print_flag;
volatile int freq = 1500;


/*
 *  Function to decide waveform type, frequency based on GPIOs
 *
 *  Parameters: None
 *
 *  Returns: None
 */
void FSM() {

	LCD_Clear();
	LCD_Write_String(0, 0, "B1:Sine Wave");
	LCD_Write_String(1, 0, "B2:Triangle Wave");
	LCD_Write_String(2, 0, "B3:Sawtooth Wave");
	LCD_Write_String(3, 0, "B4:Square Wave");
	while (flag == -1)
		;
	switch (flag) {

	case 1:
		LCD_Clear();
		LCD_Set_Mode(1);
		LCD_Bitmap(try1);
		LCD_Set_Mode(0);
		LCD_Write_String(3, 0, "Freq:");
		flag = -1;
		while (done_flag == -1) {
			freq = 1500 + (count + 1) * 500;
			char str[30];
			sprintf(str, ": %d", freq);
			LCD_Write_String(3, 2, "       ");
			LCD_Write_String(3, 2, str);
			print_flag = -1;
			TIM2->ARR = (625000 / freq) - 1;
			DMA_start(Sine_LUT, BUFFER_SIZE_128);
			while (print_flag == -1)
				;
		}
		done_flag = -1;
		print_flag = -1;
		break;

	case 2:
		LCD_Clear();
		LCD_Set_Mode(1);
		LCD_Bitmap(sqr); //square wave
		LCD_Set_Mode(0);
		LCD_Write_String(3, 0, "Freq:");
		flag = -1;
		while (done_flag == -1) {
			freq = 1500 + (count + 1) * 500;
			char str[30];
			sprintf(str, ": %d", freq);
			LCD_Write_String(3, 2, "       ");
			LCD_Write_String(3, 2, str);
			print_flag = -1;
			TIM2->ARR = (40e6 / freq) - 1;
			DMA_start(sqr_LUT, BUFFER_SIZE_2);
			while (print_flag == -1)
				;
		}
		done_flag = -1;
		print_flag = -1;
		break;

	case 3:
		LCD_Clear();
		LCD_Set_Mode(1);
		LCD_Bitmap(tri); //Tri wave
		LCD_Set_Mode(0);
		LCD_Write_String(3, 0, "Freq:");
		flag = -1;
		while (done_flag == -1) {
			freq = 1500 + (count + 1) * 500;
			char str[30];
			sprintf(str, ": %d", freq);
			LCD_Write_String(3, 2, "       ");
			LCD_Write_String(3, 2, str);
			print_flag = -1;
			TIM2->ARR = (625000 / (freq >> 1)) - 1;
			DMA_start(Triangle_LUT, BUFFER_SIZE_128);
			while (print_flag == -1)
				;
		}
		done_flag = -1;
		print_flag = -1;
		break;

	case 4:
		LCD_Clear();
		LCD_Set_Mode(1);
		LCD_Bitmap(saw); //Saw tooth wave
		LCD_Set_Mode(0);
		LCD_Write_String(3, 0, "Freq:");
		flag = -1;

		while (done_flag == -1) {

			freq = 1500 + (count + 1) * 500;
			char str[30];
			sprintf(str, ": %d", freq);
			LCD_Write_String(3, 2, "       ");
			LCD_Write_String(3, 2, str);
			print_flag = -1;
			TIM2->ARR = (625000 / freq) - 1;
			DMA_start(saw_tooth_LUT, BUFFER_SIZE_128);
			while (print_flag == -1)
				;

		}
		done_flag = -1;
		print_flag = -1;
		break;
	}
}
