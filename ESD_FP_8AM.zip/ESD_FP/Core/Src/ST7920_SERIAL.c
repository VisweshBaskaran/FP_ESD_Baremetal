/*
 * ST7920_SERIAL.c
 *
 *  Created on: 07-Jun-2019
 *      Author: poe
 */

#include <timers.h>
#include "stm32l5xx_hal.h"
#include "ST7920_SERIAL.h"
#include "GPIO.h"



/*
 * PB14: Waveform select: Sine (menu 1)
 * PE7: Waveform select: Square  (menu 2)
 * PF5: Waveform select: Triangle (menu 3)
 * PE8: Waveform select: Sawtooth (menu 4)
 * PE 11: button
 * PG6: button (done)
 * PE9: button
 */
uint8_t my_image[(128 * 64)/8];
uint8_t startRow, startCol, endRow, endCol; // coordinates of the dirty rectangle
uint8_t numRows = 64;
uint8_t numCols = 128;
uint8_t Graphic_Check = 0;

// A replacement for SPI_TRANSMIT

void SPI_Write_Byte(uint8_t byte)
{
	for(int i=0;i<8;i++)
	{
		if((byte<<i)&0x80)
				//HAL_GPIO_WritePin(SDI_PORT, SDI_PIN, GPIO_PIN_SET);  // SID=1  OR MOSI
				SDI_High();
		else
			SDI_Low(); // SID=0
		// SCLK =0  OR SCK
		SCK_Low();
		SCK_High();
		// SCLK=1

	}
}




void LCD_Write_Command (uint8_t cmd)
{
	CS_High();
	SPI_Write_Byte(0xf8+(0<<1));  // send the SYNC + RS(0)
	SPI_Write_Byte(cmd&0xf0);  // send the higher nibble first
	SPI_Write_Byte((cmd<<4)&0xf0);  // send the lower nibble
	delay_us(50);
	CS_Low();

}

void LCD_Write_Data (uint8_t data)
{
  // PUll the CS high
	CS_High();
	SPI_Write_Byte(0xf8+(1<<1));  // send the SYNC + RS(1)
	SPI_Write_Byte(data&0xf0);  // send the higher nibble first
	SPI_Write_Byte((data<<4)&0xf0);  // send the lower nibble
	delay_us(50);
	CS_Low();
	// PUll the CS LOW
}

void LCD_Write_String(int row, int col, char* string)
{
    switch (row)
    {
        case 0:
            col |= 0x80;
            break;
        case 1:
            col |= 0x90;
            break;
        case 2:
            col |= 0x88;
            break;
        case 3:
            col |= 0x98;
            break;
        default:
            col |= 0x80;
            break;
    }

    LCD_Write_Command(col);

    while (*string)
    	{
    		LCD_Write_Data(*string++);
    	}
}



// switch to graphic mode or normal mode::: enable = 1 -> graphic mode enable = 0 -> normal mode

void LCD_Set_Mode (int enable)   // 1-enable, 0-disable
{
	if (enable == 1)
	{
		LCD_Write_Command(0x30);  // 8 bit mode
		delay_ms(1);
		LCD_Write_Command(0x34);  // switch to Extended instructions
		delay_ms(1);
		LCD_Write_Command(0x36);  // enable graphics
		delay_ms(1);
		Graphic_Check = 1;  // update the variable
	}

	else if (enable == 0)
	{
		LCD_Write_Command(0x30);  // 8 bit mode
		delay_ms(1);
		Graphic_Check = 0;  // update the variable
	}
}

void LCD_Bitmap(const unsigned char* graphic)
{
	uint8_t x, y;
	for(y = 0; y < 64; y++)
	{
		if(y < 32)
		{
			for(x = 0; x < 8; x++)							// Draws top half of the screen.
			{												// In extended instruction mode, vertical and horizontal coordinates must be specified before sending data in.
				LCD_Write_Command(0x80 | y);				// Vertical coordinate of the screen is specified first. (0-31)
				LCD_Write_Command(0x80 | x);				// Then horizontal coordinate of the screen is specified. (0-8)
				LCD_Write_Data(graphic[2*x + 16*y]);		// Data to the upper byte is sent to the coordinate.
				LCD_Write_Data(graphic[2*x+1 + 16*y]);	// Data to the lower byte is sent to the coordinate.
			}
		}
		else
		{
			for(x = 0; x < 8; x++)							// Draws bottom half of the screen.
			{												// Actions performed as same as the upper half screen.
				LCD_Write_Command(0x80 | (y-32));			// Vertical coordinate must be scaled back to 0-31 as it is dealing with another half of the screen.
				LCD_Write_Command(0x88 | x);
				LCD_Write_Data(graphic[2*x + 16*y]);
				LCD_Write_Data(graphic[2*x+1 + 16*y]);
			}
		}

	}
}




void LCD_Clear()
{
	if (Graphic_Check == 1)  // if the graphic mode is set
	{
		uint8_t x, y;
		for(y = 0; y < 64; y++)
		{
			if(y < 32)
			{
				LCD_Write_Command(0x80 | y);
				LCD_Write_Command(0x80);
			}
			else
			{
				LCD_Write_Command(0x80 | (y-32));
				LCD_Write_Command(0x88);
			}
			for(x = 0; x < 8; x++)
			{
				LCD_Write_Data(0);
				LCD_Write_Data(0);
			}
		}
	}

	else
	{
		LCD_Write_Command(0x01);   // clear the display using command
		HAL_Delay(2); // delay >1.6 ms
	}
}


void LCD_Init(void)
{
	// RESET=0
	RST_Low();
	delay_ms(10);
	// RESET=1
	RST_High();
	delay_ms(50);   //wait for >40 ms
	LCD_Write_Command(0x30);  // 8bit mode
	delay_us(110);  //  >100us delay

	LCD_Write_Command(0x30);  // 8bit mode
	delay_us(40);  // >37us delay

	LCD_Write_Command(0x08);  // D=0, C=0, B=0
	delay_us(110);  // >100us delay

	LCD_Write_Command(0x01);  // clear screen
	delay_ms(12);  // >10 ms delay


	LCD_Write_Command(0x06);  // cursor increment right no shift
	delay_ms(1);  // 1ms delay

	LCD_Write_Command(0x0C);  // D=1, C=0, B=0
	delay_ms(1);  // 1ms delay

	LCD_Write_Command(0x02);  // return to home
	delay_ms(1);  // 1ms delay

}

