/**
 ******************************************************************************
 * @file           : main.c
 * @author         : Visweshwaran Baskaran and Vidhya Palaniappan
 * @brief          : Driver file to run the application, waveform generator
 ******************************************************************************
 * @attention
 *
​ ​*​ ​Copyright​ ​(C)​ 2023 ​by​ Visweshwaran Baskaran and Vidhya Palaniappan
​ ​*
​ ​*​ ​Redistribution,​ ​modification​ ​or​ ​use​ ​of​ ​this​ ​software​ ​in​ ​source​ ​or​ ​binary
​ ​*​ ​forms​ ​is​ ​permitted​ ​as​ ​long​ ​as​ ​the​ ​files​ ​maintain​ ​this​ ​copyright.​ ​Users​ ​are
​ ​*​ ​permitted​ ​to​ ​modify​ ​this​ ​and​ ​use​ ​it​ ​to​ ​learn​ ​about​ ​the​ ​field​ ​of​ ​embedded
​ ​*​ ​software.​ Visweshwaran Baskaran​, Vidhya Palaniappan  ​and​ ​the​ ​University​ ​of​ ​Colorado​ ​are​ ​not​ ​liable​ ​for
​ ​*​ ​any​ ​misuse​ ​of​ ​this​ ​material.
​ ​*
 *
 ******************************************************************************
 */


#include "FSM.h"

int main(void)
{
	TIM2_init();
	TIM1_init();
	GPIO_Init();
	DAC_init();
	DMA_init();
	LCD_Init();
	LCD_Clear();
	while (1)
	{
		FSM();
	 }
}







