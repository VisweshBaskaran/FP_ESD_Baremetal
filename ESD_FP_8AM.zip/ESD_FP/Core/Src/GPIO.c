
#include "GPIO.h"
#include "timers.h"

enum wave_type
{
	SINE,
	TRIANGLE,
	SAWTOOTH,
	SQUARE
};

#define ONE_SEC 42949670<<1
int done_flag = -1, flag = -1, count = 0, print_flag = -1;
uint32_t prev_tick = 0;
void GPIO_Init(void) {
	// Enable GPIOB and GPIOF clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN | RCC_AHB2ENR_GPIOEEN
			| RCC_AHB2ENR_GPIOFEN | RCC_AHB2ENR_GPIOGEN;

	// Configure PB14 as EXTI source
	GPIOB->MODER &= ~GPIO_MODER_MODE14_Msk;
	GPIOB->MODER |= GPIO_MODER_MODE14_1;  // Set PB14 as input mode
	GPIOB->PUPDR &= ~GPIO_PUPDR_PUPD14_Msk;
	GPIOB->PUPDR |= GPIO_PUPDR_PUPD14_0;  // Enable pull-up on PB14
	EXTI->EXTICR[3] &= ~EXTI_EXTICR4_EXTI14_Msk;
	EXTI->EXTICR[3] |= EXTI_EXTICR4_EXTI14_Pos;  // Connect PB14 to EXTI14
	EXTI->RTSR1 |= EXTI_RTSR1_RT14;  // Enable rising edge trigger on EXTI14
	EXTI->IMR1 |= EXTI_IMR1_IM14;    // Enable interrupt for EXTI14

	// Configure PE7 as EXTI source
	GPIOE->MODER &= ~GPIO_MODER_MODE7_Msk;
	GPIOE->MODER |= GPIO_MODER_MODE7_1;
	GPIOE->PUPDR &= ~GPIO_PUPDR_PUPD7_Msk;
	GPIOE->PUPDR |= GPIO_PUPDR_PUPD7_0;

	EXTI->EXTICR[3] &= ~EXTI_EXTICR2_EXTI7_Msk;
	EXTI->EXTICR[3] |= EXTI_EXTICR2_EXTI7_Pos;

	EXTI->RTSR1 |= EXTI_RTSR1_RT7;
	EXTI->IMR1 |= EXTI_IMR1_IM7;

	// Configure PE8 as EXTI source
	GPIOE->MODER &= ~GPIO_MODER_MODE8_Msk;
	GPIOE->MODER |= GPIO_MODER_MODE8_1;  // Set PE8 as input mode
	GPIOE->PUPDR &= ~GPIO_PUPDR_PUPD8_Msk;
	GPIOE->PUPDR |= GPIO_PUPDR_PUPD8_0;  // Enable pull-up on PE8
	EXTI->EXTICR[2] &= ~EXTI_EXTICR3_EXTI8_Msk;
	EXTI->EXTICR[2] |= EXTI_EXTICR3_EXTI8_Pos;  // Connect PE8 to EXTI8
	EXTI->RTSR1 |= EXTI_RTSR1_RT8;  // Enable rising edge trigger on EXTI8
	EXTI->IMR1 |= EXTI_IMR1_IM8;    // Enable interrupt for EXTI8

	// Configure PF5 as EXTI source
	GPIOF->MODER &= ~GPIO_MODER_MODE5_Msk;
	GPIOF->MODER |= GPIO_MODER_MODE5_1;  // Set PF5 as input mode
	GPIOF->PUPDR &= ~GPIO_PUPDR_PUPD5_Msk;
	GPIOF->PUPDR |= GPIO_PUPDR_PUPD5_0;  // Enable pull-up on PF5
	EXTI->EXTICR[1] &= ~EXTI_EXTICR2_EXTI5_Msk;
	EXTI->EXTICR[1] |= EXTI_EXTICR2_EXTI5_Pos;  // Connect PF5 to EXTI5
	EXTI->RTSR1 |= EXTI_RTSR1_RT5;  // Enable rising edge trigger on EXTI5
	EXTI->IMR1 |= EXTI_IMR1_IM5;    // Enable interrupt for EXTI5

	// Configure PE11 as EXTI source
	GPIOE->MODER &= ~GPIO_MODER_MODE11_Msk;
	GPIOE->MODER |= GPIO_MODER_MODE11_1;  // Set PE11 as input mode
	GPIOE->PUPDR &= ~GPIO_PUPDR_PUPD11_Msk;
	GPIOE->PUPDR |= GPIO_PUPDR_PUPD11_0;  // Enable pull-up on PE11

	EXTI->EXTICR[2] &= ~EXTI_EXTICR3_EXTI11_Msk;
	EXTI->EXTICR[2] |= EXTI_EXTICR3_EXTI11_Pos;  // Connect PE11 to EXTI11

	EXTI->RTSR1 |= EXTI_RTSR1_RT11;  // Enable rising edge trigger on EXTI11
	EXTI->IMR1 |= EXTI_IMR1_IM11;    // Enable interrupt for EXTI11

	// Configure PE9 as EXTI source
	GPIOE->MODER &= ~GPIO_MODER_MODE9_Msk;
	GPIOE->MODER |= GPIO_MODER_MODE9_1;  // Set PE9 as input mode
	GPIOE->PUPDR &= ~GPIO_PUPDR_PUPD9_Msk;
	GPIOE->PUPDR |= GPIO_PUPDR_PUPD9_0;  // Enable pull-up on PE9
	EXTI->EXTICR[2] &= ~EXTI_EXTICR3_EXTI9_Msk;
	EXTI->EXTICR[2] |= EXTI_EXTICR3_EXTI9_Pos;  // Connect PE9 to EXTI9
	EXTI->RTSR1 |= EXTI_RTSR1_RT9;  // Enable rising edge trigger on EXTI9
	EXTI->IMR1 |= EXTI_IMR1_IM9;    // Enable interrupt for EXTI9

	// Enable EXTI15_IRQn and EXTI9_IRQn interrupts
	NVIC_EnableIRQ(EXTI15_IRQn);
	NVIC_EnableIRQ(EXTI9_IRQn);

	// Configure PB0, PB1, PB2, PF11 as outputs
	GPIOB->MODER &= ~(GPIO_MODER_MODE0_Msk | GPIO_MODER_MODE1_Msk
			| GPIO_MODER_MODE2_Msk);
	GPIOB->MODER |= (GPIO_MODER_MODE0_0 | GPIO_MODER_MODE1_0
			| GPIO_MODER_MODE2_0);
	GPIOF->MODER &= ~GPIO_MODER_MODE11_Msk;
	GPIOF->MODER |= GPIO_MODER_MODE11_0;

	// Set PB0, PB1, PB2, PF11 output type as push-pull
	GPIOB->OTYPER &= ~(GPIO_OTYPER_OT0_Msk | GPIO_OTYPER_OT1_Msk
			| GPIO_OTYPER_OT2_Msk);
	GPIOF->OTYPER &= ~GPIO_OTYPER_OT11_Msk;

	// Set PB0, PB1, PB2, PF11 output speed as high
	GPIOB->OSPEEDR &= ~(GPIO_OSPEEDR_OSPEED0_Msk | GPIO_OSPEEDR_OSPEED1_Msk
			| GPIO_OSPEEDR_OSPEED2_Msk);
	GPIOB->OSPEEDR |= (GPIO_OSPEEDR_OSPEED0_1 | GPIO_OSPEEDR_OSPEED1_1
			| GPIO_OSPEEDR_OSPEED2_1);
	GPIOF->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED11_Msk;
	GPIOF->OSPEEDR |= GPIO_OSPEEDR_OSPEED11_1;

	// Set PB0, PB1, PB2, PF11 as no pull-up, no pull-down
	GPIOB->PUPDR &= ~(GPIO_PUPDR_PUPD0_Msk | GPIO_PUPDR_PUPD1_Msk
			| GPIO_PUPDR_PUPD2_Msk);
	GPIOF->PUPDR &= ~GPIO_PUPDR_PUPD11_Msk;
}


void EXTI15_IRQHandler(void)
{
    if (EXTI->RPR1 & EXTI_RPR1_RPIF14)  // Check if PB14 interrupt flag is set
    {
        // PB14 is high
        EXTI->RPR1 = EXTI_RPR1_RPIF14;  // Clear PB14 interrupt flag
        flag = SINE;
    }

    // Add other interrupt handlers for the remaining pins
    if (EXTI->RPR1 & EXTI_RPR1_RPIF8)  // Check if PE8 interrupt flag is set
    {
        // PE8 is high
    	flag = SQUARE;
        EXTI->RPR1 = EXTI_RPR1_RPIF8;  // Clear PE8 interrupt flag
    }

    if (EXTI->RPR1 & EXTI_RPR1_RPIF11  && ((prev_tick - get_tick()) > (ONE_SEC)))  // Check if PE11 interrupt flag is set
    {
        // PE11 is high
    	if(count>=36) count = 36;
    	else count++;
    	print_flag = 1;
    	prev_tick = get_tick();
        EXTI->RPR1 = EXTI_RPR1_RPIF11;  // Clear PE11 interrupt flag
    }

    if (EXTI->RPR1 & EXTI_RPR1_RPIF9   && ((prev_tick - get_tick()) > (ONE_SEC)))  // Check if PE9 interrupt flag is set
    {
        // PE9 is high
    	if(count == 0) count = 0;
    	else count--;
    	print_flag = 1;
    	prev_tick = get_tick();
        EXTI->RPR1 = EXTI_RPR1_RPIF9;  // Clear PE9 interrupt flag
    }
    if (EXTI->RPR1 & EXTI_RPR1_RPIF6 && ((prev_tick - get_tick()) > (ONE_SEC)))  // Check if PG6 interrupt flag is set
    {
        // PG6 is high
    	done_flag =1;
    	//freq = 2000;
    	count = 0;
    	print_flag = 1;
    	prev_tick = get_tick();
        EXTI->RPR1 = EXTI_RPR1_RPIF6;  // Clear PG6 interrupt flag
    }
}

void EXTI9_IRQHandler(void)
{
    if (EXTI->RPR1 & EXTI_RPR1_RPIF7)  // Check if PE7 interrupt flag is set
    {
        // PE7 is high
    	flag = 	TRIANGLE;
        EXTI->RPR1 = EXTI_RPR1_RPIF7;  // Clear PE7 interrupt flag
    }

    if (EXTI->RPR1 & EXTI_RPR1_RPIF5)  // Check if PF5 interrupt flag is set
    {
        // PF5 is high
    	flag = SAWTOOTH;
        EXTI->RPR1 = EXTI_RPR1_RPIF5;  // Clear PF5 interrupt flag
    }
}



void SDI_High(void) {
	GPIOB->BSRR |= GPIO_BSRR_BS2_Msk;
}

void SDI_Low(void) {
	GPIOB->BSRR &= ~GPIO_BSRR_BS2_Msk;
}

void SCK_High(void) {
	GPIOB->BSRR |= GPIO_BSRR_BS0_Msk;
}

void SCK_Low() {
	GPIOB->BSRR &= ~GPIO_BSRR_BS0_Msk;
}

void CS_High(void) {
	GPIOB->BSRR |= GPIO_BSRR_BS1_Msk;
}

void CS_Low(void) {
	GPIOB->BSRR &= ~GPIO_BSRR_BS1_Msk;
}

void RST_High(void) {
	GPIOF->BSRR |= GPIO_BSRR_BS11_Msk;
}

void RST_Low(void) {
	GPIOF->BSRR &= ~GPIO_BSRR_BS11_Msk;
}

void EXTI5_IRQHandler() {

}
