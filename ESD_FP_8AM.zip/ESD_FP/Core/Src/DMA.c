/*****************************************************************************
​ ​*​ ​Copyright​ ​(C)​ 2023 ​by​ Visweshwaran Baskaran and Vidhya Palaniappan
​ ​*
​ ​*​ ​Redistribution,​ ​modification​ ​or​ ​use​ ​of​ ​this​ ​software​ ​in​ ​source​ ​or​ ​binary
​ ​*​ ​forms​ ​is​ ​permitted​ ​as​ ​long​ ​as​ ​the​ ​files​ ​maintain​ ​this​ ​copyright.​ ​Users​ ​are
​ ​*​ ​permitted​ ​to​ ​modify​ ​this​ ​and​ ​use​ ​it​ ​to​ ​learn​ ​about​ ​the​ ​field​ ​of​ ​embedded
​ ​*​ ​software.​ Visweshwaran Baskaran, Vidhya Palaniappan​ ​and​ ​the​ ​University​ ​of​ ​Colorado​ ​are​ ​not​ ​liable​ ​for
​ ​*​ ​any​ ​misuse​ ​of​ ​this​ ​material.
​ ​*
*****************************************************************************/
/*
 * File name: DMA.h
 * Author: Visweshwaran Baskaran and Vidhya Palaniappan
 * File Description:
 * 	This file defines the APIs to configure and send data through DMA
 *	The functions defined in this file are:
 *		void DMA_init(void)
 *		void DMA_start(uint32_t* buffer, uint16_t buffer_size)
 *		void DMA1_Channel1_IRQHandler(void)
 *
 * Created on: 01-May-2023
 *
*/

#include "DMA.h"

void DMA_init(void)
{
	RCC->AHB1ENR |= RCC_AHB1ENR_DMA1EN;
    DMA1_Channel1->CCR &= ~(DMA_CCR_EN);
    DMA1_Channel1->CCR |= (DMA_CCR_PL_1 | DMA_CCR_DIR | DMA_CCR_CIRC | DMA_CCR_MSIZE_0 | DMA_CCR_PSIZE_0 | DMA_CCR_MINC | DMA_CCR_TCIE);
    NVIC_EnableIRQ(DMA1_Channel1_IRQn);
    DMA1_Channel1->CCR |= DMA_CCR_EN;
}

void DMA_start(uint32_t* buffer, uint16_t buffer_size)
{
    DMA1_Channel1->CNDTR = buffer_size;
    DMA1_Channel1->CPAR = (uint32_t)(&DAC1->DHR12R1);
    DMA1_Channel1->CM1AR = (uint32_t)buffer;
}


void DMA1_Channel1_IRQHandler(void)
{
    if (DMA1->ISR & DMA_ISR_TCIF1) {
        DMA1->IFCR |= DMA_IFCR_CTCIF1;
        DAC1->CR &= ~(DAC_CR_EN1);
    }
}
