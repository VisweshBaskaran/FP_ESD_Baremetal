/*
 * GPIO.h
 *
 *  Created on: May 8, 2023
 *      Author: Viswesh
 */

#ifndef INC_GPIO_H_
#define INC_GPIO_H_
#include "stm32l5xx_hal.h"

void GPIO_Init(void);

void SDI_High();

void SDI_Low();

void SCK_High();

void SCK_Low();

void CS_High();

void CS_Low();

void RST_High();

void RST_Low();



#endif /* INC_GPIO_H_ */
