/*****************************************************************************
​ ​*​ ​Copyright​ ​(C)​ 2023 ​by​ Visweshwaran Baskaran and Vidhya Palaniappan
​ ​*
​ ​*​ ​Redistribution,​ ​modification​ ​or​ ​use​ ​of​ ​this​ ​software​ ​in​ ​source​ ​or​ ​binary
​ ​*​ ​forms​ ​is​ ​permitted​ ​as​ ​long​ ​as​ ​the​ ​files​ ​maintain​ ​this​ ​copyright.​ ​Users​ ​are
​ ​*​ ​permitted​ ​to​ ​modify​ ​this​ ​and​ ​use​ ​it​ ​to​ ​learn​ ​about​ ​the​ ​field​ ​of​ ​embedded
​ ​*​ ​software.​ Visweshwaran Baskaran, Vidhya Palaniappan​ ​and​ ​the​ ​University​ ​of​ ​Colorado​ ​are​ ​not​ ​liable​ ​for
​ ​*​ ​any​ ​misuse​ ​of​ ​this​ ​material.
​ ​*
*****************************************************************************/
/*
 * File name: DMA.h
 * Author: Visweshwaran Baskaran and Vidhya Palaniappan
 * File Description:
 * 	This file declares the APIs to configure and send data through DMA
 *	The functions declared in this file are:
 *		void DMA_init(void)
 *		void DMA_start(uint32_t* buffer, uint16_t buffer_size)
 *		void DMA1_Channel1_IRQHandler(void)
 *
 * Created on: 01-May-2023
 *
*/

#ifndef INC_DMA_H_
#define INC_DMA_H_

#include <stm32l5xx_hal.h>

void DMA_init();
void DMA_start(uint32_t* buffer, uint16_t buffer_size);
void DMA1_Channel1_IRQHandler(void);
#endif /* INC_DMA_H_ */
