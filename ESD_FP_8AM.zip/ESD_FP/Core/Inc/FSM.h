/*****************************************************************************
​ ​*​ ​Copyright​ ​(C)​ 2023 ​by​ Visweshwaran Baskaran and Vidhya Palaniappan
​ ​*
​ ​*​ ​Redistribution,​ ​modification​ ​or​ ​use​ ​of​ ​this​ ​software​ ​in​ ​source​ ​or​ ​binary
​ ​*​ ​forms​ ​is​ ​permitted​ ​as​ ​long​ ​as​ ​the​ ​files​ ​maintain​ ​this​ ​copyright.​ ​Users​ ​are
​ ​*​ ​permitted​ ​to​ ​modify​ ​this​ ​and​ ​use​ ​it​ ​to​ ​learn​ ​about​ ​the​ ​field​ ​of​ ​embedded
​ ​*​ ​software.​ Visweshwaran Baskaran​, Vidhya Palaniappan ​and​ ​the​ ​University​ ​of​ ​Colorado​ ​are​ ​not​ ​liable​ ​for
​ ​*​ ​any​ ​misuse​ ​of​ ​this​ ​material.
​ ​*
*****************************************************************************/
/*
 * File name: FSM.h
 * Author: Visweshwaran Baskaran and Vidhya Palaniappan
 * File Description:
 * 	This file declares the API required for the state machine that drives the application
 *
 * Created on: 01-May-2023
*/


#ifndef INC_FSM_H_
#define INC_FSM_H_

#include <stdint.h>
#include "stdio.h"

#include "timers.h"
#include "GPIO.h"
#include "DAC.h"
#include "DMA.h"
#include "ST7920_SERIAL.h"

/*
 *  Function to decide waveform type, frequency based on GPIOs
 *
 *  Parameters: None
 *
 *  Returns: None
 */
void FSM(void);

#endif /* INC_FSM_H_ */
