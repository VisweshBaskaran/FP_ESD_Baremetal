
/*****************************************************************************
​ ​*​ ​Copyright​ ​(C)​ 2023 ​by​ Visweshwaran Baskaran and Vidhya Palaniappan
​ ​*
​ ​*​ ​Redistribution,​ ​modification​ ​or​ ​use​ ​of​ ​this​ ​software​ ​in​ ​source​ ​or​ ​binary
​ ​*​ ​forms​ ​is​ ​permitted​ ​as​ ​long​ ​as​ ​the​ ​files​ ​maintain​ ​this​ ​copyright.​ ​Users​ ​are
​ ​*​ ​permitted​ ​to​ ​modify​ ​this​ ​and​ ​use​ ​it​ ​to​ ​learn​ ​about​ ​the​ ​field​ ​of​ ​embedded
​ ​*​ ​software.​ Visweshwaran Baskaran, Vidhya Palaniappan​ ​and​ ​the​ ​University​ ​of​ ​Colorado​ ​are​ ​not​ ​liable​ ​for
​ ​*​ ​any​ ​misuse​ ​of​ ​this​ ​material.
​ ​*
*****************************************************************************/
/*
 * File name: timers.h
 * Author: Visweshwaran Baskaran and Vidhya Palaniappan
 * File Description:
 * 	This file declares the APIs to configure timer 1 and timer
 *	The functions declared in this file are:
 *			void TIM2_init(void);
 *			void TIM1_init(void);
 *			void delay_us(uint32_t us);
 * 			void delay_ms(uint32_t ms);
 *			uint32_t get_tick(void);
 *
 * Created on: 01-May-2023
 *
 * Sources:
 *
*/
#ifndef DELAY_H_
#define DELAY_H_

#include "stdint.h"

/*
 * Function to configure timer 2 for DMA transfer
 *
 * Parameters: None
 *
 * Returns: None
 */
void TIM2_init(void);

/*
 * Function to configure timer 1 for delays
 *
 * Parameters: None
 *
 * Returns: None
 */
void TIM1_init(void);

/*
 * Function to add a delay of 'n' us
 *
 * Parameters:
 * us, no. of microseconds of delay required
 *
 * Returns: None
 */
void delay_us(uint32_t us);

/*
 * Function to add a delay of 'n' ms
 *
 * Parameters:
 * ms, no. of milliseconds of delay required
 *
 * Returns: None
 */
void delay_ms(uint32_t ms);

/*
 * Function to return current tick time of timer 1
 *
 * Parameters: None
 *
 * Returns: curr_tick, current tick time
 */
uint32_t get_tick(void);

#endif /* DELAY_H_ */
