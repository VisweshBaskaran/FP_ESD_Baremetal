/*****************************************************************************
​ ​*​ ​Copyright​ ​(C)​ 2023 ​by​ Visweshwaran Baskaran and Vidhya Palaniappan
​ ​*
​ ​*​ ​Redistribution,​ ​modification​ ​or​ ​use​ ​of​ ​this​ ​software​ ​in​ ​source​ ​or​ ​binary
​ ​*​ ​forms​ ​is​ ​permitted​ ​as​ ​long​ ​as​ ​the​ ​files​ ​maintain​ ​this​ ​copyright.​ ​Users​ ​are
​ ​*​ ​permitted​ ​to​ ​modify​ ​this​ ​and​ ​use​ ​it​ ​to​ ​learn​ ​about​ ​the​ ​field​ ​of​ ​embedded
​ ​*​ ​software.​ Visweshwaran Baskaran​, Vidhya Palaniappan ​and​ ​the​ ​University​ ​of​ ​Colorado​ ​are​ ​not​ ​liable​ ​for
​ ​*​ ​any​ ​misuse​ ​of​ ​this​ ​material.
​ ​*
*****************************************************************************/
/*
 * File name: DAC.c
 * Author: Visweshwaran Baskaran and Vidhya Palaniappan
 * File Description:
 * 	This file declares the APIs to initiate the DAC module
 *
 * The functions declared in this file are:
 * 				void DAC_init(void);
 * Created on: 01-May-2023
 *
 * Sources:
 * 			1) “Bare Metal” STM32 Programming (Part 9): Fun With DMA :
 * 				https://vivonomicon.com/2019/07/05/bare-metal-stm32-programming-part-9-dma-megamix/
 *
 * 			2) DAC in STM32:
 * 				https://controllerstech.com/dac-in-stm32/
*/

#ifndef INC_DAC_H_
#define INC_DAC_H_

#include <stm32l5xx_hal.h>

/*
 * Function to initiate DAC module
 *
 * Parameters: None
 *
 * Returns: None
 */
void DAC_init();
#endif /* INC_DAC_H_ */
